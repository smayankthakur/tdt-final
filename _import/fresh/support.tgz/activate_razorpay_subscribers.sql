-- Activates Razorpay-active subscribers who are not active in Supabase (ginni2 "User" table).
-- Access runs until each person's next Razorpay billing date. Generated 2026-10-09.
-- Review, then paste into Supabase -> SQL Editor -> Run.
begin;

update "User" u
set "subscriptionStatus"  = 'active',
    "subscriptionPlan"    = 'monthly',
    "subscriptionEndsAt"  = v.ends::timestamptz,
    "subscriptionExpires" = v.ends::timestamp
from (values
  ('sushantgudekar39@gmail.com', '2026-11-06'),
  ('fantibhagat4@gmail.com', '2026-11-06'),
  ('sarikanshinde27@gmail.com', '2026-11-04'),
  ('sagarikadey22@gmail.com', '2026-11-03'),
  ('kprajakta212@gmail.com', '2026-11-02'),
  ('jyotika657@gmail.com', '2026-10-27'),
  ('divya.lal2007@gmail.com', '2026-10-26'),
  ('chan.anand0929@gmail.com', '2026-10-24'),
  ('tikiranibhue96@gmail.com', '2026-10-23'),
  ('sanyogitarishumi@gmail.com', '2026-10-14'),
  ('trivedisaurabh766@gmail.com', '2026-10-13'),
  ('shradhadargan@gmail.com', '2026-10-13'),
  ('ankush1409@gmail.com', '2026-10-13'),
  ('dasn7768@gmail.com', '2026-10-13'),
  ('shazminkhan04@gmail.com', '2026-10-13'),
  ('at908193@gmail.com', '2026-10-12'),
  ('heenababriya99831@gmail.com', '2026-10-12'),
  ('laraibwarish334@gmail.com', '2026-10-11'),
  ('roshantilenmc@gmail.com', '2026-10-11'),
  ('aishwaryapandji4@gmail.com', '2026-10-11'),
  ('binder.gill2283@gmail.com', '2026-10-11'),
  ('sushpasushpabhosag@gmail.com', '2026-10-10'),
  ('shripankajradhe1793@gmail.com', '2026-10-10'),
  ('varshajogire@gmail.com', '2026-11-09'),
  ('ruchikatoch32@gmail.com', '2026-11-09'),
  ('jaswal20@yahoo.co.in', '2026-11-08'),
  ('sy7556485@gmail.com', '2026-11-07'),
  ('tanidhawan.td@gmail.com', '2026-11-06'),
  ('navbrar943@gmail.com', '2026-11-04'),
  ('kanak2515anjel@gmail.com', '2026-11-03'),
  ('rachchaudhary27@gmail.com', '2026-11-02'),
  ('saritapradhan666@gmail.com', '2026-10-24'),
  ('ramyab0404@gmail.com', '2026-10-24'),
  ('svikas.2310@gmail.com', '2026-10-23'),
  ('simmichadha1970@gmail.com', '2026-10-23'),
  ('kambojraj962@gmail.com', '2026-10-21'),
  ('harshadadeshmukh357@gmail.com', '2026-10-17'),
  ('vijay.dewangan25.vd@gmail.com', '2026-10-16'),
  ('beherapranati774@gmail.com', '2026-10-13'),
  ('ahanamatta785@gmail.com', '2026-10-12'),
  ('kharatpriyanka96@gmail.com', '2026-10-10'),
  ('rupeshbelose07@gmail.com', '2026-10-10'),
  ('rprityroy777@gmail.com', '2026-10-10'),
  ('ruparandive@gmail.com', '2026-10-10'),
  ('anuradha.chakrabarty@gmail.com', '2026-11-08'),
  ('nainsichaudhary4@gmail.com', '2026-11-08'),
  ('monalisa.bhattacharya11@gmail.com', '2026-11-07'),
  ('mitali1487@gmail.com', '2026-11-07'),
  ('swamiprobuddhananda@yahoo.com', '2026-11-06'),
  ('sutarmegha2001@gmail.com', '2026-11-06')
) as v(email, ends)
where lower(u.email) = v.email;

-- Should report UPDATE 50
commit;
