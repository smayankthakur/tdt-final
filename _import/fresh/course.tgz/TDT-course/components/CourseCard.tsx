import { isBookingClosed, type Course } from "@/lib/courses";
import BookingStatus from "./BookingStatus";
import Glyph from "./Glyph";

export default function CourseCard({
  course,
  onOpenDetails,
}: {
  course: Course;
  onOpenDetails: () => void;
}) {
  const closed = isBookingClosed(course);

  return (
    <div className="group relative flex flex-col overflow-hidden rounded-3xl border border-[color:var(--hairline)] bg-[color:var(--bg-surface)] transition-all duration-300 hover:-translate-y-1.5 hover:border-[color:var(--gold)]/50 hover:shadow-[0_20px_45px_-15px_rgba(212,175,106,0.25)]">
      <div className="relative flex h-40 items-center justify-center overflow-hidden bg-[color:var(--bg-surface-2)]">
        {course.image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={course.image}
            alt={course.title}
            className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div
            className="absolute inset-0 opacity-70"
            style={{
              background:
                "radial-gradient(circle at 30% 20%, rgba(167,139,250,0.35), transparent 55%), radial-gradient(circle at 80% 80%, rgba(212,175,106,0.25), transparent 50%)",
            }}
          />
        )}
        {course.image && <div className={`absolute inset-0 ${closed ? "bg-black/55" : "bg-black/25"}`} />}
        {!course.image && (
          <Glyph name={course.glyph} className="relative h-20 w-20 text-[color:var(--gold-light,#ecd9a8)]" />
        )}
        <span className="absolute left-4 top-4 rounded-full bg-black/30 px-3 py-1 text-[11px] font-medium uppercase tracking-wide text-[color:var(--ivory)] backdrop-blur">
          {course.tag}
        </span>
        <span className="absolute right-4 top-4 rounded-full bg-[color:var(--gold)] px-3 py-1 text-[11px] font-bold text-[color:var(--bg-void)]">
          {course.price}
        </span>
        {closed && (
          <span className="absolute inset-x-0 bottom-0 bg-black/60 py-2 text-center text-xs font-bold uppercase tracking-[0.2em] text-[color:var(--ivory)] backdrop-blur">
            🔒 Booking Closed!
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col p-6">
        <h3 className="font-serif text-2xl text-[color:var(--ivory)]">{course.title}</h3>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-[color:var(--muted)]">{course.summary}</p>

        <ul className="mt-4 space-y-1.5 text-[13px] text-[color:var(--muted)]">
          {course.schedule.slice(0, 3).map((s) => (
            <li key={s} className="flex items-start gap-2">
              <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-[color:var(--gold)]" />
              {s}
            </li>
          ))}
        </ul>

        <div className="mt-6 flex flex-wrap items-center gap-3">
          <BookingStatus course={course} size="sm" />
          <button
            onClick={onOpenDetails}
            className="inline-flex items-center gap-1 text-sm font-medium text-[color:var(--purple-light,#a78bfa)] underline decoration-transparent underline-offset-4 transition hover:decoration-current"
          >
            Course details →
          </button>
        </div>
      </div>
    </div>
  );
}
