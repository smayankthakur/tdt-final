# The Divine Tarot — one website

Everything that used to be five separate sites now runs as **one Next.js app on
one domain, with one Supabase project and one login**.

| Page | Path | Was |
| --- | --- | --- |
| Home, About, Premium, Contact, Privacy, Terms, Refund policy | `/`, `/about`, `/premium`, `/contact`, `/privacy`, `/terms`, `/refund-policy` | thedivinetarotonline.com |
| Ginni Ki Baatein (reading chat, ₹199 / 30-day pass) | `/reading`, `/reset-password` | reading.thedivinetarotonline.com |
| Courses (5 recorded courses) | `/courses`, `/courses/[slug]` | learn.thedivinetarotonline.com |
| Kundli Milan (free score + ₹99 report) | `/kundli-milan` | thedivinetarotonline.com/kundli-milan |
| Personal Reading (voice/Meet call booking) | `/personal-reading`, `/personal-reading/form`, `/personal-reading/admin` | booking.thedivinetarotonline.com |
| Support, account deletion, app link | `/support`, `/delete-account`, `/app` | support.thedivinetarotonline.com |

Old subdomains redirect permanently to the new paths (see `middleware.ts`), and
their `/api/...` callbacks keep working, so payment links and webhooks that
Razorpay already knows about still land.

## Stack

- Next.js 14 (App Router), React 18, Tailwind
- **Supabase**: Auth (email + password) and Postgres for every feature, private Storage bucket for support screenshots
- Razorpay (Checkout for the reading pass and Kundli report, Payment Links for personal readings)
- Resend (reading/newsletter/support email), Gmail SMTP (booking confirmations with calendar invite), Google Calendar API (Meet links)
- Sentry, Upstash (optional edge rate limit), Vercel Cron

## First-time setup

1. **Supabase project** — create one (or reuse the reading app's). In the SQL editor run, in order:
   `supabase/01_newsletter_subscribers.sql`, `02_daily_newsletter.sql`, `03_youtube_newsletter.sql`,
   `04_kundli_orders.sql`, `10_unified_platform.sql`. All are safe to re-run.
2. **Supabase Auth settings** — Authentication → Providers → Email: enabled. "Confirm email" can stay on:
   the site creates accounts already confirmed. Authentication → URL configuration → Site URL
   `https://thedivinetarotonline.com`.
3. **Environment** — copy `.env.example` to `.env.local` (and into Vercel). Generate each secret with
   `openssl rand -hex 32`.
4. **Admin access** for `/personal-reading/admin`: either set `BOOKING_ADMIN_TOKEN`, or sign in on `/reading`
   with the owner's account and set that user's `app_metadata` to `{"role":"admin"}` in Supabase.
5. `npm install && npm run dev`.

## Moving the existing data (once)

```bash
# dry run — prints counts, writes nothing
SUPABASE_DB_URL="postgresql://postgres:<pw>@db.<ref>.supabase.co:5432/postgres" \
LEGACY_DATABASE_URL="<the reading app's old DIRECT_URL>" \
FIREBASE_SERVICE_ACCOUNT_JSON='<booking service-account JSON, one line>' \
npm run migrate:legacy

# then for real
npm run migrate:legacy -- --commit
```

- Reading-app users keep their passwords (bcrypt hashes move into Supabase Auth), passes, bonus readings,
  referral codes, referrals, last 30 chat messages and orders.
- Personal-reading orders, bookings, payment problems and the slot settings move from Firestore.
  (`npm i -D firebase-admin` first if you migrate bookings.)
- Re-running skips anything already moved.

## Razorpay webhooks

| URL | Events | Secret env |
| --- | --- | --- |
| `/api/razorpay/reading-webhook` | `payment.captured`, `order.paid` | `RAZORPAY_READING_WEBHOOK_SECRET` |
| `/api/booking/razorpay-webhook` | `payment_link.paid` | `BOOKING_RAZORPAY_WEBHOOK_SECRET` |
| `/api/kundli-report/webhook` | `payment.captured` | `KUNDLI_RAZORPAY_WEBHOOK_SECRET` |

## Cron jobs (vercel.json)

| Path | When (UTC) | What |
| --- | --- | --- |
| `/api/newsletter/daily` | 03:00 daily | daily teaser email + WhatsApp |
| `/api/youtube/cron` | 04:00 daily | emails subscribers when a new YouTube video is out |
| `/api/cron/cleanup-accounts` | 21:00 daily | deletes accounts that never bought a pass after 24 h (client rule) |

All require `Authorization: Bearer $CRON_SECRET` (Vercel sends it).

## Domains (Vercel)

Add `thedivinetarotonline.com`, `www.`, `reading.`, `learn.`, `booking.`, `support.` (and `chat.` if it still
resolves) to this one project. Remove them from the old projects first. The middleware handles the redirects.

## Security model

- RLS is on for every table. Signed-in users can read only their own profile, chat and orders; nothing
  can be written from the browser.
- Money and slot logic run inside Postgres functions (`credit_reading_order`, `consume_reading`,
  `pr_hold_slot`, `pr_mark_paid`, `pr_claim_slot`) that only the server may call — no double credits,
  no double bookings.
- Payment signatures and webhooks use constant-time HMAC checks. Login, reset, support, booking and
  subscribe are rate-limited.

## Scripts

`npm run dev` · `npm run build` · `npm run typecheck` · `npm run lint` · `npm test` · `npm run migrate:legacy`
